调用地址:http://xxx.com/giturl.php
调用参数:return = json / jsonpro / url / urlpro / img
json：返回一条标准json数据(图片地址)
jsonpro：返回十条标准json数据(图片地址)
url：直接返回一条图片链接
urlpro:直接返回十条图片链接
img：直接显示图片不返回图片链接
免费程序，遵循开源协议，请勿用于商业用途 转载请加出处 多谢合作~
程序自带1000多张图片

倾丞博客
blog.qcair.cc
瑾忆小栈
www.qiuzq.cn