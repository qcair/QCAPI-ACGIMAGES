<?php
$FileURL = 'pc-img-github-202007127812560.txt'; 
//此处可读取远程资源文件，也可读取本地资源文件
$APIname = "QCAPI-Github-Wallpaper"; //此处填写API名称
$giturlArr = file($FileURL);

$giturlData = [];

foreach ($giturlArr as $key => $value) {
    $value = trim($value);
    if (!empty($value)) {
        $giturlData[] = trim($value);
    }
}

//随机一张
$randKey = rand(0, count($giturlData));
$imageUrl = $giturlData[$randKey];

//随机十张
$randKeys = array_rand($giturlData, 10);
$imageUrls = [];
foreach ($randKeys as $key) {
    $imageUrls[] = $giturlData[$key];
}

//json
$json = array(
    "server" => "$APIname",
    "code" => "200",
    "type" => "image"
);

$type = $_GET['return'];

switch ($type) {
    case 'url':
        echo $imageUrl;
        echo "<br>";
        echo "200OK-" .$_SERVER['SERVER_NAME'];
        echo '<br>';
        echo "Get Information Success from " .$APIname;
        break;

    case 'img':
        $img = file_get_contents($imageUrl, true);
        header("Content-Type: image/jpeg;");
        echo $img;
        break;

    case 'urlpro':
        foreach ($imageUrls as $imgUrl) {
            echo $imgUrl;
            echo '<br>';
        }
        echo "200OK-" .$_SERVER['SERVER_NAME'];
        echo '<br>';
        echo "Get Information Success from " .$APIname;
        break;

    case 'jsonpro':
        header('Content-type:text/json');
        $json['acgUrls'] = $imageUrls;
        echo json_encode($json);
        break;

    case 'json':
        $json['acgUrl'] = $imageUrl;
        $imageInfo = getimagesize($imageUrl);
        $json['width'] = "$imageInfo[0]";
        $json['height'] = "$imageInfo[1]";
        header('Content-type:text/json');
        echo json_encode($json);
        break;

    default:
        header("Location:" . $imageUrl);
        break;
}